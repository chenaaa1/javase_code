package 运动员和教练;

public interface SpeakEnglish {
    public abstract void speak();
}
