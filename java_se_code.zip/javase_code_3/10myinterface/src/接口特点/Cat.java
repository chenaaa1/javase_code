package 接口特点;

public class Cat implements jumpping{
    @Override
    public void jump() {
        System.out.println("猫可以跳高了");
    }
}
