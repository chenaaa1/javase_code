package 接口特点;

public abstract class Dog implements jumpping{

}
