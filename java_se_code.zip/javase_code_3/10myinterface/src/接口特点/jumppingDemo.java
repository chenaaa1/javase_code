package 接口特点;

public class jumppingDemo {
    public static void main(String[] args) {
//        jumpping j = new jumpping();

        jumpping j = new Cat();
        j.jump();

    }
}
