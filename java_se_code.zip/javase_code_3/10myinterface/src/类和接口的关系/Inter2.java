package 类和接口的关系;

public interface Inter2 {
}
