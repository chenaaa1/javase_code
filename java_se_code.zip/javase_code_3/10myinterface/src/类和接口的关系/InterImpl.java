package 类和接口的关系;

public class InterImpl extends Object implements Inter1,Inter2,Inter3{
}
