package 类和接口的关系;

public interface Inter3 extends Inter1,Inter2{
}
