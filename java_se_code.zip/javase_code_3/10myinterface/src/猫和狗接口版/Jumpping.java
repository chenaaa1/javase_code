package 猫和狗接口版;

public interface Jumpping {
    public abstract void jump();
}
