package 接口的成员特点;

//public class Interlmpl implements Inter{

public class Interlmpl extends Object implements Inter{
    public Interlmpl(){
        super();
    }

    @Override
    public void method() {
        System.out.println("");
    }

    @Override
    public void show() {
        System.out.println("show");
    }
}
