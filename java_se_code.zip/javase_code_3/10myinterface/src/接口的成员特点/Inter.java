package 接口的成员特点;

public interface Inter {
    public int num = 10;
    public final int num2 = 20;
//    public static final int num3 = 30;
    int num3 = 30;

//    public Inter(){}

//    public void show(){}

    public abstract void method();

    void show();
}
