package 接口的成员特点;

public class InterfaceDemo {
    public static void main(String[] args) {
        Inter i = new Interlmpl();
//        i.num = 20;
        System.out.println(i.num);
//        i.num2 = 40;
        System.out.println(i.num2);
        System.out.println(Inter.num);
    }
}
