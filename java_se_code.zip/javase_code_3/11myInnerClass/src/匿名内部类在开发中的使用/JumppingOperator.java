package 匿名内部类在开发中的使用;
//接口操作类，里面有一个方法，方法的参数是接口名

public class JumppingOperator {

    public void method(Jumpping j){ //new Cat();  //new Dog();
        j.jump();
    }
}
