package 匿名内部类在开发中的使用;

public interface Jumpping {

    void jump();
}
