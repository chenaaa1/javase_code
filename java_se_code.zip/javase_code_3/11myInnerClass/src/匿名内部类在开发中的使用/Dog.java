package 匿名内部类在开发中的使用;

public class Dog implements Jumpping{

    @Override
    public void jump() {
        System.out.println("狗可以跳高了");
    }
}
