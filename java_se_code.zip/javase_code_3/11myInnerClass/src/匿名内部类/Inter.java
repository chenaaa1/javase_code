package 匿名内部类;

public interface Inter {

    void show();
}
