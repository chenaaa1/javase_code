package final修饰符;

public class Zi extends Fu{

    public int age = 100;

    public void show(){
        System.out.println(age);
    }

//    @Override
//    public void method(){
//        System.out.println("Zi method");
//    }
}
