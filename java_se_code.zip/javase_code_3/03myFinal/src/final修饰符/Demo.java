package final修饰符;

public class Demo {
    public static void main(String[] args) {
        Zi z = new Zi();
        z.method();
        z.show();
    }
}
