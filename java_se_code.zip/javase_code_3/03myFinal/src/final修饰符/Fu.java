package final修饰符;

public class Fu {

    public final void method(){
        System.out.println("Fu method");
    }
}
