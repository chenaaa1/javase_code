package final修饰局部变量;

public class Student {
    public int age = 20;
}
