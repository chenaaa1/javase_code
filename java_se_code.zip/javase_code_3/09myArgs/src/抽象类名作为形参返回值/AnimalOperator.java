package 抽象类名作为形参返回值;

public class AnimalOperator {

    public void useAniaml(Animal a){ //Animal a = new Cat();
        a.eat();
    }

    public Animal getAnimal(){
        Animal a = new Cat();
        return a;
    }
}
