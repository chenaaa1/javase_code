package 抽象类名作为形参返回值;

public abstract class Animal {

    public abstract void eat();
}
