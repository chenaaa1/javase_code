package 抽象类名作为形参返回值;

public class AnimalDemo {
    public static void main(String[] args) {
        //创建操作类对象，并调用方法
        AnimalOperator ao = new AnimalOperator();
        Animal a = new Cat();
        ao.useAniaml(a);

        Animal a2 = ao.getAnimal(); //new Cat();
        a2.eat();
    }
}
