package 接口名作为形参和返回值;

public interface Jumpping {

    void jump();

}
