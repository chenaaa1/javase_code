package 接口名作为形参和返回值;

public class Cat implements Jumpping{

    @Override
    public void jump() {
        System.out.println("猫可以跳高了");
    }
}
