package 多态中成员访问特点;

public class Animal {

    public int age = 40;

    public void eat(){
        System.out.println("动物吃东西");
    }

}
