package 多态;

//多态的前提和体现：
//    有继承/实现关系
//    有方法重写
//    有父类引用子类对象

public class AnimalDemo {
    public static void main(String[] args) {
        //有父类引用指向子类对象
        Animal a = new Cat();
    }
}
