package 多态;

public class Animal {

    public void eat(){
        System.out.println("动物吃东西");
    }
}
