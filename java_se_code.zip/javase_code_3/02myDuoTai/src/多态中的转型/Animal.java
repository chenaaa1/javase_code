package 多态中的转型;

public class Animal {

    public void eat(){
        System.out.println("动物吃东西");
    }

}
