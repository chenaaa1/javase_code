package 多态的好处和弊端;

public class Cat extends Animal{

    @Override
    public void eat(){
        System.out.println("猫吃鱼");
    }

}
