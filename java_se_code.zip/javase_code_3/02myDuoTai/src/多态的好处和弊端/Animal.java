package 多态的好处和弊端;

public class Animal {

    public void eat(){
        System.out.println("动物吃东西");
    }

}
