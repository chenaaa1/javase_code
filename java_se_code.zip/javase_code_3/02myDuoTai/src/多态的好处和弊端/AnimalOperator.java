package 多态的好处和弊端;
//动物操作类

public class AnimalOperator {

//    public void useAnimal(Cat c){ //Cat c = new Cat();
//        c.eat();
//    }
//
//    public void useAnimal(Dog d){ //Cat c = new Cat();
//        d.eat();
//    }

    public void useAnimal(Animal a){
        //Animal a = new Cat();
        //Animal a = new Dog();
        a.eat();
//        a.lookDoor();
    }

}
