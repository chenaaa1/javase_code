package 多态的好处和弊端;

public class Pig extends Animal{

    @Override
    public void eat(){
        System.out.println("猪吃白菜");
    }
}
