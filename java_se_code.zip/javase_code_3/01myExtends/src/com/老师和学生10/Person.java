package com.老师和学生10;

public class Person {
    private String name;
    private int age;

//    alt+insert:构造函数，选函数
    public Person() {
    }

//    alt+insert:构造函数，选下面的方法
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

//    alt+insert:getter and setter，选下面的方法
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
