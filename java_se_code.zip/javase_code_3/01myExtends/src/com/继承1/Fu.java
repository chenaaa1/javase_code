package com.继承1;

public class Fu {
    public void show(){
        System.out.println("show方法被调用");
    }
}
