package com.继承1;

public class Zi extends Fu{
    public void method(){
        System.out.println("method方法被调用");
    }
}
