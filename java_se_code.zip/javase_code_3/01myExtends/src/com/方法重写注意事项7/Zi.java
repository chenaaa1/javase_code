package com.方法重写注意事项7;

public class Zi extends Fu{

/*    private void show() {
        System.out.println("ZI中show()被调用");
    }*/

/*    public void method(){
        System.out.println("zI中method（）方法被调用");
    } */

    @Override
    public void method(){
        System.out.println("Zi中method（）方法被调用");
    }

}
