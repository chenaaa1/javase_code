package com.方法重写注意事项7;

public class Fu {

    private void show(){
        System.out.println("Fu中show()被调用");
    }

/*    public void method(){
        System.out.println("Fu中method（）方法被调用");
    }*/

    void method(){
        System.out.println("Fu中method（）方法被调用");
    }
}
