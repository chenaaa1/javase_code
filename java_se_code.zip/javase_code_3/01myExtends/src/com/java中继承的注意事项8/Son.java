package com.java中继承的注意事项8;

/*public class Son extends Father, Mother{
}*/

public class Son extends Father{
}
