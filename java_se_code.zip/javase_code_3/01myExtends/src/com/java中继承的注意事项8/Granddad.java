package com.java中继承的注意事项8;

public class Granddad {

    public void drink(){
        System.out.println("爷爷爱喝酒");
    }
}
