package com.java中继承的注意事项8;

public class Mother {

    public void dance(){
        System.out.println("妈妈爱跳舞");
    }
}
