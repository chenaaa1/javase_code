package com.java中继承的注意事项8;

public class Father extends Granddad{

    public void smoke(){
        System.out.println("爸爸爱抽烟");
    }
}
