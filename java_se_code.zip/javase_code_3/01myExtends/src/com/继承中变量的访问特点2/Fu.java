package com.继承中变量的访问特点2;

public class Fu {
    //年龄
    public int age = 40;
}
