package com.方法重写6;

public class Phone {
    public void call(String name){
        System.out.println("给" + name + "打电话");
    }
}
