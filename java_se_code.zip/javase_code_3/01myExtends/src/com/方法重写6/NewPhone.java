package com.方法重写6;

public class NewPhone extends Phone{
/*
   public void call(String name){
        System.out.println("开启视频功能");
//        System.out.println("给" + name + "打电话");
        super.call(name);
    }
    */

//    @Override
    public void calll(String name){
        System.out.println("开启视频功能");
        //        System.out.println("给" + name + "打电话");
        super.call(name);
    }
}
