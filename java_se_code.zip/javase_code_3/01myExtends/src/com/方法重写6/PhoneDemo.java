package com.方法重写6;

public class PhoneDemo {
    public static void main(String[] args) {
        //创建对象，调用方法
        Phone p  = new Phone();
        p.call("张丽莎");
        System.out.println("--------");

        NewPhone np = new NewPhone();
        np.call("张丽莎");
    }
}
