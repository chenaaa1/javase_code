package com.老师和学生9;

public class Demo {
    public static void main(String[] args) {
        //创建老师类对象进行测试
        Teacher t1 = new Teacher();
        t1.setName("张丽莎");
        t1.setAge(30);
        System.out.println(t1.getName() + "," + t1.getAge());

        Teacher t2 = new Teacher("丽莎", 33);
        System.out.println(t2.getName() + "," + t2.getAge());
        t2.teach();
    }
}

