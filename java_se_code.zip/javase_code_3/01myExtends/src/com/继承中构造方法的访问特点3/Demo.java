package com.继承中构造方法的访问特点3;

public class Demo {
    public static void main(String[] args) {
        //创建对象
        Zi z = new Zi();

        Zi z2 = new Zi(20);
    }
}
