package com.继承中构造方法的访问特点3;

public class Fu {

   /* public Fu(){
        System.out.println("Fu中无参构造方法被调用");
    }*/

    public Fu(){};

    public Fu(int age){
        System.out.println("Fu中带参构造方法被调用");
    }

}
