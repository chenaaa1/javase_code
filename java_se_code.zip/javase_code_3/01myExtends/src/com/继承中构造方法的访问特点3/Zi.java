package com.继承中构造方法的访问特点3;

public class Zi extends Fu{

    public Zi(){
//        super();
        System.out.println("Zi中无参构造方法被调用");
    }

    public Zi(int age){
//        super();
        System.out.println("Zi中带参构造方法被调用");
    }

}
