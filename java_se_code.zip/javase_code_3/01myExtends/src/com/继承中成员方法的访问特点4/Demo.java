package com.继承中成员方法的访问特点4;

public class Demo {
    public static void main(String[] args) {
        //创建对象，调用方法
        Zi z =new Zi();
        z.method();
        z.show();
    }
}
