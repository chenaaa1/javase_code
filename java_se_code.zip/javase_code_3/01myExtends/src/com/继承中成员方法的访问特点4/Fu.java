package com.继承中成员方法的访问特点4;

public class Fu {

    public void show(){
        System.out.println("Fu中show()方法被调用");
    }
}
