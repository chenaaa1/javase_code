package com.super关键字5;

public class Fu {
    public int age = 40;
}
