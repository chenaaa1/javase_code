package com.super关键字5;

public class Zi extends Fu{
    public int age = 20;

    public void show(){
        int age = 30;
        System.out.println(age);
        //我要访问本类的成员变量，怎么办呢？
        System.out.println(this.age);
        //我要访问父类的成员变量age，怎么办呢？
        System.out.println(super.age);
    }
}