package cn.itheima;

import cn.itcast.Fu;

public class Zi extends Fu{

    public static void main(String[] args) {
        //创建Zi的对象，测试看有哪些方法可以使用
        Zi z = new Zi();
        z.show3();
        z.show4();
    }
}
