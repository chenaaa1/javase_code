package 抽象类;

public abstract class Animal {
//    public void eat(){
//        System.out.println("吃东西");
//    }

    public abstract void eat();
}
