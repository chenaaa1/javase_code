package 抽象类特点;

public abstract class Dog extends Animal{
}
