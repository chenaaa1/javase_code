package 抽象类特点;

public class AnimalDemo {
    public static void main(String[] args) {
//        Animal a = new Animal();
        Animal a = new Cat();
        a.eat();
        a.sleep();
    }
}
