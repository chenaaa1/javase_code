package cn.itcast;

public class Teacher {

    public void teach(){
        System.out.println("放弃教书");
    }
}
