package com.itheima;

import cn.itcast.Teacher;
public class Demo {
    public static void main(String[] args) {
//        Teacher t = new Teacher();

/*
       cn.itcast.Teacher t = new cn.itcast.Teacher();
        t.teach();

        cn.itcast.Teacher t2 = new cn.itcast.Teacher();
        t2.teach();
        */

        Teacher t = new Teacher();
        t.teach();
    }
}
