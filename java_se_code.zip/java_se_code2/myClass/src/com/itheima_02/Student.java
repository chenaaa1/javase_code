package com.itheima_02;
//学生类
public class Student {
    //成员变量
    String name;
    int age;

    //成员方法
    public void study(){
        System.out.println("好好学习，天天向上");
    }

    public void dohomework(){
        System.out.println("键盘敲烂，月薪过万");
    }
}
