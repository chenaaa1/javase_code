package 字节流写数据;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamDemo01 {
    public static void main(String[] args) throws IOException {
        //创建字符输出流对象
        //创建文件输出流以指定的名称写入文件
        FileOutputStream fos = new FileOutputStream("18myByteStream\\fos.txt");

        //将指定的字节写入此文件输出流
        fos.write(97);

        //最后都要释放资源
        //关闭此文件输出流并释放与此流相关联的任何系统资源
        fos.close();
    }
}
