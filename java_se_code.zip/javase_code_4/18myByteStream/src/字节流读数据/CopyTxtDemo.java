package 字节流读数据;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

//把一个文件复制到模块目录下
public class CopyTxtDemo {
    public static void main(String[] args) throws IOException {
        //根据数据源创建字节输入流对象
        FileInputStream fis = new FileInputStream("E:\\itcast\\窗里窗外.txt");
        //根据目的地创建字节输出流对象
        FileOutputStream fos = new FileOutputStream("18myByteStream\\窗里窗外.txt");

        //读写数据，复制文本文件(一次读取一个字节，一次写入一个字节)
        int by;
        while ((by=fis.read())!=-1){
            fos.write(by);
        }

        //释放资源
        fos.close();
        fis.close();
    }
}
