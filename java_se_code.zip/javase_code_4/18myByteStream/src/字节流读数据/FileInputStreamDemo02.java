package 字节流读数据;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputStreamDemo02 {
    public static void main(String[] args) throws IOException {
        //创建字节输入流对象
        FileInputStream fis = new FileInputStream("18myByteStream\\fos.txt");
/*
        //调用字节输入流对象的读取方法
        //int read (byte[] b)：从该输入流中最多b.length个字节的数据到一个字节数组
        byte[] bys = new byte[5];

        //第一次读取数据
        int len = fis.read();
        System.out.println(len);
        //String (byte[] bytes)
//        System.out.println(new String(bys));
        System.out.println(new String(bys,0,len));

        //第二次读取数据
        len = fis.read();
        System.out.println(len);
//        System.out.println(new String(bys));
        System.out.println(new String(bys,0,len));
        */

        byte[] bys = new byte[1024];
        int len;
        while ((len=fis.read(bys))!=-1){
            System.out.println(new String(bys,0,len));
        }

        //释放资源
        fis.close();
    }
}
