package _Date;
//public Date();分配一个date对象并初始化，方便它代表它被分配的时间，精确到毫秒
//public Date(long date);分配一个date对象，并将其初始化为表示从标准基准时间起指定的毫秒数

import java.util.Date;

public class DateDemo01 {
    public static void main(String[] args) {
        //public Date();分配一个date对象并初始化，方便它代表它被分配的时间，精确到毫秒
        Date di = new Date();
        System.out.println(di);

        //public Date(long date);分配一个date对象，并将其初始化为表示从标准基准时间起指定的毫秒数
        long date = 1000*60*60;
        Date d2 = new Date(date);
        System.out.println(d2);
    }
}
