package Object类的equals方法;

public class Student {
    private String name;
    private int age;

    public Student() {
    }

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

//    alt+insert:选择equals中default类型的
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
//        this---s1;
//        o----s2;
//        比较地址是否相同，相同则返回true
        if (o == null || getClass() != o.getClass()) return false;
//        判断参数是否为null；
//        判断两个对象是否来自同一个类;

        Student student = (Student) o;
        //向下转型

        if (age != student.age) return false;
//        比较年龄是否相同
        return name != null ? name.equals(student.name) : student.name == null;
//        比较姓名内容是否相同;
    }

}
