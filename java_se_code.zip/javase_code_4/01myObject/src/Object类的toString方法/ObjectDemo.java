package Object类的toString方法;
//Object是类层次结构的根，每个类都可以将Object作为超类，所有类都直接或间接的继承该类
//看方法的源码，选中方法按下ctrl+B
public class ObjectDemo {
    public static void main(String[] args) {
        Student s = new Student();
        s.setName("张丽莎");
        s.setAge(20);
        System.out.println(s);
        System.out.println(s.toString());
    }
}
