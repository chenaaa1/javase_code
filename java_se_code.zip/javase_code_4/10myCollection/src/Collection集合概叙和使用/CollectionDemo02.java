package Collection集合概叙和使用;

import java.util.ArrayList;
import java.util.Collection;

//alt+7 打开一个窗口，能够看到所有类的信息

public class CollectionDemo02 {
    public static void main(String[] args) {
        //创建集合对象
        Collection<String> c = new ArrayList<String>();

        //boolean add(E e);添加元素
//        System.out.println(c.add("hello"));
//        System.out.println(c.add("world"));
//        System.out.println(c.add("张丽莎"));
        c.add("hello");
        c.add("world");
        c.add("张丽莎");

        //boolean remove(Object o):从集合中移除指定的元素
//        System.out.println(c.remove("world"));

        //void clear():清空集合中的元素
//        c.clear();

        //boolean contains(Object o):判断集合中是否存在指定的元素
//        System.out.println(c.contains("world"));

        //boolean isEmpty():判断集合是否为空
//        System.out.println(c.isEmpty());

        //int size():查看集合汇总元素的个数
        System.out.println(c.size());

        //输出集合对象
        System.out.println(c);
    }
}
