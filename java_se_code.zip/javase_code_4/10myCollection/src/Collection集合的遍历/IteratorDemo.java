package Collection集合的遍历                             ;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class IteratorDemo {
    public static void main(String[] args) {
        //创建集合对象
        Collection<String> c = new ArrayList<String>();

        //添加元素
        c.add("hello");
        c.add("world");
        c.add("java");

        //Iterator<E> iterator(); 返回此集合中元素的迭代器，通过集合的iterator()方法实现
        Iterator<String> it = c.iterator();

        //E next(); 返回迭代中的下一个元素
       /* System.out.println(it.next());
        System.out.println(it.next());
        System.out.println(it.next());*/

        //boolean hasNext();如果迭代具有更多元素，则返回true
//        if (it.hasNext()){
//            System.out.println(it.next());
//        }
//        if (it.hasNext()){
//            System.out.println(it.next());
//        }
//        if (it.hasNext()){
//            System.out.println(it.next());
//        }
//        if (it.hasNext()){
//            System.out.println(it.next());
//        }

        //用while循环改进判断
        while (it.hasNext()){
            String s = it.next();
            System.out.println(s);
        }

    }
}
