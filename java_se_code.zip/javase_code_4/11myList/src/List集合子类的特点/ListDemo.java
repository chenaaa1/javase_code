package List集合子类的特点;
//List常用子类：ArrayList,LinkedList
//ArrayList:底层数据结构是数组
//LinkedList:底层数据结构是链表

import java.util.ArrayList;
import java.util.LinkedList;

public class ListDemo {
    public static void main(String[] args) {
        //创建集合对象
        ArrayList<String> array = new ArrayList<String>();

        array.add("hello");
        array.add("world");
        array.add("java");

        //遍历
        for (String s : array){
            System.out.println(s);
        }
        System.out.println("--------");

        LinkedList<String> linkedList = new LinkedList<String>();

        linkedList.add("hello");
        linkedList.add("world");
        linkedList.add("java");

        for (String s : linkedList){
            System.out.println(s);
        }
    }
}
