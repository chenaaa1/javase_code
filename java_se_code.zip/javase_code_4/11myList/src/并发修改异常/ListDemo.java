package 并发修改异常;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListDemo {
    public static void main(String[] args) {
        //创建集合对象
        List<String> list = new ArrayList<String >();

        //添加元素
        list.add("hello");
        list.add("world");
        list.add("java");

        //遍历集合，看是否又“world”这个元素，有则添加一个“javaee”
//        Iterator<String> it = list.iterator();
//        while (it.hasNext()){
//            String s = it.next();
//            if (s.equals("world")){
//                list.add("javaee");
//            }
//        }

        for (int i=0; i<list.size(); i++){
            String s = list.get(i);
            if (s.equals("world")){
                list.add("javaee");
            }
        }

        System.out.println(list);
    }
}
