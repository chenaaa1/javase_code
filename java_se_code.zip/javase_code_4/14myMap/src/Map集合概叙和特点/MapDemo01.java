package Map集合概叙和特点;
/*
Map集合概叙:
    Interface Map<K, V> K:键的类型; V:值的类型
    将键映射到值的对象，不能包含重复的键，每个键最多映射到一个值

创建Map集合的对象:
多态的方式
具体的实现类HashMap
*/

import java.util.HashMap;
import java.util.Map;

public class MapDemo01 {
    public static void main(String[] args) {
        //创建集合对象
        Map<String,String> map = new HashMap<String,String>();

        //V put(K key, V value)将指定 的值与该映射中的指定键相关联
        map.put("1","张丽莎");
        map.put("2","丽莎");
        map.put("3","莎");
        map.put("3","皮卡丘");

        //输出集合对象
        System.out.println(map);
    }
}
