package HashMap集合练习之键是Student值是String;

import java.util.HashMap;
import java.util.Set;

public class HashMapDemo {
    public static void main(String[] args) {
        //创建HashMap集合对象
        HashMap<Student,String> hm = new HashMap<Student, String>();

        //创建学生对象
        Student s1 = new Student("张丽莎", 20);
        Student s2 = new Student("丽莎", 19);
        Student s3 = new Student("莎", 18);
        Student s4 = new Student("莎", 18);

        //把学生添加到集合
        hm.put(s1,"湛江");
        hm.put(s2,"坡头");
        hm.put(s3,"吴川");
        hm.put(s4,"霞山");

        //遍历集合
        Set<Student> keySet = hm.keySet();
        for (Student key : keySet){
            String value = hm.get(key);
            System.out.println(key.getName()+","+key.getAge()+","+value);
        }
    }
}
