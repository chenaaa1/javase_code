package HashMap集合练习之键时String值是Student;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class HashMapDemo {
    public static void main(String[] args) {
        //创建HashMap集合对象
        HashMap<String,Student> hm = new HashMap<String, Student>();

        //创建学生对象
        Student s1 = new Student("张丽莎",20);
        Student s2 = new Student("丽莎",19);
        Student s3 = new Student("莎",18);

        //把学生添加到集合
        hm.put("001", s1);
        hm.put("002", s2);
        hm.put("003", s3);

        //方式一，键找值
        Set<String> keySet = hm.keySet();
        for (String key : keySet){
            Student value =  hm.get(key);
            System.out.println(key + "," + value.getAge());
        }
        System.out.println("--------");

        //方式2:键值对对象找键和值
        Set<Map.Entry<String,Student>> entrySet = hm.entrySet();
        for (Map.Entry<String,Student> me : entrySet){
            String key = me.getKey();
            Student value = me.getValue();
            System.out.println(key + "," + value.getAge());
        }
    }
}
