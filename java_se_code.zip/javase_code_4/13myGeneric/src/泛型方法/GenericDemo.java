package 泛型方法;

public class GenericDemo {
    public static void main(String[] args) {
//        Generic g = new Generic();
//        g.show("张丽莎");
//        g.show(30);
//        g.show(true);
//        g.show(12.34);

//        Generic<String> g1 = new Generic<String>();
//        g1.show("张丽莎");
//
//        Generic<Integer> g2 = new Generic<Integer>();
//        g2.show(20);
//
//        Generic<Boolean> g3 = new Generic<Boolean>();
//        g3.show(true);

        Generic g = new Generic();
        g.show("丽莎");
        g.show(30);
        g.show(true);
        g.show(12.34);
    }
}
