package 可变参数;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

public class ArgsDemo02 {
    public static void main(String[] args) {
/*
       //public static <T> List<T> asList (T...a):返回由指定数组支持的固定大小的列表
        List<String> list = Arrays.asList("hello", "world", "java");

//        list.add("javaee");
//        list.remove("world");
        list.set(1, "javaee");

        System.out.println(list);
        */

/*
        //public static <E> List<E> of (E... elements):返回包含任意数量元素的不可变列表
        List<String> list = List.of("hello", "world", "java", "world");

//        list.add("javaee");
//        list.remove("java");
//        list.set(1, "javaee");

        System.out.println(list);
    }
}
*/

        //public static <E> Set<E> of (E...elements):返回一个包含任意数量元素的不可变集合
//        Set<String> set = Set.of("hello", "world", "java", "world");
        Set<String> set = Set.of("hello", "world", "java");

//        set.add("javaee");
//        set.remove("world");

        System.out.println(set);
    }
}