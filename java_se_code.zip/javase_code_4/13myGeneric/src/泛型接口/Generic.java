package 泛型接口;

public interface Generic<T> {
    void show(T t);
}
