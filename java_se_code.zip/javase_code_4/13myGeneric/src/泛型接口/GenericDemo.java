package 泛型接口;

public class GenericDemo {
    public static void main(String[] args) {
        Generic<String> g1 = new Genericlmpl<String>();
        g1.show("张丽莎");

        Generic<Integer> g2 = new Genericlmpl<Integer>();
        g2.show(30);
    }
}
