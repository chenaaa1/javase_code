package Calendar常用方法;

import java.util.Calendar;

public class CalendarDemo {
    public static void main(String[] args) {
        //获取日期类对象
        Calendar c = Calendar.getInstance();

        //需求1：3年前的今天
//        c.add(Calendar.YEAR, -3);
//
//        int year = c.get(Calendar.YEAR);
//        int month = c.get(Calendar.MONTH) + 1;
//        int date = c.get(Calendar.DATE);
//        System.out.println(year + "年" + month + "月" + date + "日");

//        //需求2：十年前后的5天前：
//        c.add(Calendar.YEAR, 10);
//        c.add(Calendar.DATE, -5);
//
//        int year = c.get(Calendar.YEAR);
//        int month = c.get(Calendar.MONTH) + 1;
//        int date = c.get(Calendar.DATE);
//        System.out.println(year + "年" + month + "月" + date + "日");

        //public final void set(int year, int month, int date):设置当前日历的年月日
        c.set(2048, 11, 11);
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH) + 1;
        int date = c.get(Calendar.DATE);
        System.out.println(year + "年" + month + "月" + date + "日");
    }
}
