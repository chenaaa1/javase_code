package 成绩排序;

import java.util.Comparator;
import java.util.TreeSet;

public class TreeSetDemo {
    public static void main(String[] args) {
        //创建TreeSet集合对象，通过比较器进行排序
        TreeSet<Student> ts = new TreeSet<Student>(new Comparator<Student>() {
            @Override
            public int compare(Student s1, Student s2) {
                int num = (s2.getsum())-(s1.getsum());
                int num2 = num==0 ? s1.getChinese() - s2.getChinese() : num;
                int num3 = num2==0 ? s1.getName().compareTo(s2.getName()) : num2;
                return num3;
            }
        });

        //创建学生对象
        Student s1 = new Student("张丽莎",98,100);
        Student s2 = new Student("丽莎",95,69);
        Student s3 = new Student("莎",85,38);
        Student s4 = new Student("皮卡丘",52,46);
        Student s5 = new Student("雷电法王",31,16);
        Student s6 = new Student("杰尼龟",27,20);
        Student s7 = new Student("飞天鼠",27,20);

        //把学生添加到集合
        ts.add(s1);
        ts.add(s2);
        ts.add(s3);
        ts.add(s4);
        ts.add(s5);
        ts.add(s6);
        ts.add(s7);

        //遍历集合
        for (Student s : ts){
            System.out.println(s.getName()+","+s.getChinese()+","+s.getMath()+","+s.getsum());
        }
    }
}
