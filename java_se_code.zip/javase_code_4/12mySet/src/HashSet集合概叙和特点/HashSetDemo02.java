package HashSet集合概叙和特点;

import java.util.HashSet;

public class HashSetDemo02 {
    public static void main(String[] args) {
        //创建HashSet集合对象
        HashSet<Student> hs = new HashSet<Student>();

        //创建学生对象
        Student s1 = new Student("张丽莎", 20);
        Student s2 = new Student("丽莎", 20);
        Student s3 = new Student("莎", 20);

        Student s4 = new Student("莎", 20);

        //把学生添加到集合
        hs.add(s1);
        hs.add(s2);
        hs.add(s3);
        hs.add(s4);

        //遍历集合（增强for）
        for (Student s : hs){
            System.out.println(s.getName()+","+s.getAge());
        }
    }
}
