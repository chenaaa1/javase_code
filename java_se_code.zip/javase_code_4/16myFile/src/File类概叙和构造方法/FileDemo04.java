package File类概叙和构造方法;
//File类删除功能

import java.io.File;
import java.io.IOException;

public class FileDemo04 {
    public static void main(String[] args) throws IOException {
        //在当前模块目录下创建java.txt文件
        File f1 = new File("16myFile\\java.txt");
//        System.out.println(f1.createNewFile());

        //删除当前模块目录下的java.txt文件
        System.out.println(f1.delete());
        System.out.println("---------");

        //在当前模块目录下创建itcast目录
        File f2 = new File("16myFile\\itcast");
//        System.out.println(f2.mkdir());

        //删除当前模块目录下的itcast目录
        System.out.println(f2.delete());
        System.out.println("---------");

        //在当前目录下创建一个目录itcast，然后在该目录下创建一个文件java.txt
        File f3 = new File("16myFile\\itcast");
//        System.out.println(f3.mkdir());
        File f4 = new File("16myFile\\itcast\\java.txt");
//        System.out.println(f4.createNewFile());

//        删除当前模块下的目录itcast
        System.out.println(f4.delete());
        System.out.println(f3.delete());
    }
}
