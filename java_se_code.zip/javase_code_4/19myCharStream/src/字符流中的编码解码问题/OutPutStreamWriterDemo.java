package 字符流中的编码解码问题;
//字符流写数据的5种方式

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class OutPutStreamWriterDemo {
    public static void main(String[] args) throws IOException {
        //创建一个使用默认字符编码的OutoutSatreamWriter
        OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream("19myCharStream\\osw.txt"));

        /*
        //写一个字符
        osw.write(97);
        //void flush()刷新流
        osw.flush();
        osw.write(98);
        osw.flush();
        osw.write(99);
         */

        //写入一个字符数组
        char[] chs = {'a', 'b', 'c', 'd', 'e', };
//        osw.write(chs);

        //写入字符数组的一部分
//        osw.write(chs, 0, chs.length);
//        osw.write(chs, 1, 3);

        //写一个字符串
//        osw.write("abcde");

        //写一个字符串的一部分
//        osw.write("abcde", 0, "abcde".length());
        osw.write("abcde",1,3);

        //释放资源，close会先刷新流再释放资源
        osw.close();
    }
}
