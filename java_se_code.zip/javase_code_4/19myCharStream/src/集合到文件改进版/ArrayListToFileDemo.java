package 集合到文件改进版;
//把ArrayList集合中的学生数据写入文件，要求每一个学生对象的数据作为文件中的一行数据

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class ArrayListToFileDemo {
    public static void main(String[] args) throws IOException {
        //创建ArrayList集合
        ArrayList<Student> array = new ArrayList<Student>();

        //创建学生对象
        Student s1 = new Student("1", "张丽莎", 20, "湛江");
        Student s2 = new Student("2", "丽莎", 19, "坡头");
        Student s3 = new Student("3", "莎", 18, "皮卡丘");

        //把学生对象添加到集合中
        array.add(s1);
        array.add(s2);
        array.add(s3);

        //创建字符缓冲输出流对象
        BufferedWriter bw = new BufferedWriter(new FileWriter("19myCharStream\\students.txt"));

        //遍历集合，得到每一个学生对象
        for (Student s : array){
            //把学生对象拼接成指定格式的字符串
            StringBuilder sb = new StringBuilder();
            sb.append(s.getSid()).append(",").append(s.getName()).append(",").append(s.getAge()).append(",").append(s.getAddress());

            //调用字符缓冲输出流对象的方法写数据
            bw.write(sb.toString());
            bw.newLine();
            bw.flush();
        }

        //释放资源
        bw.close();
    }
}
