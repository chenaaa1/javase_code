package 字符流复制java文件;
//复制java文件改进版

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyJavaDemo02 {
    public static void main(String[] args) throws IOException {
        //根据数据源创建字节输入流对象
        FileReader fr = new FileReader("19myCharStream\\ConversionStreamDemo.java");
        //根据目的地创建字符输出流对象
        FileWriter fw = new FileWriter("19myCharStream\\Copy.java");

        //读写数据，复制文件
//        int ch;
//        while ((ch=fr.read())!=-1){
//            fw.write(ch);
//        }

        char[] chs = new char[1024];
        int len;
        while ((len=fr.read(chs))!=-1){
            fw.write(chs,0,len);
        }

        //释放资源
        fw.close();
        fr.close();
    }
}
