package 字符缓冲流;
//字符缓冲流的特有功能
//BufferedWriter:
//    void newLine():写一行行分隔符
//
//BufferedReader:
//    public String readLine():读一行文字，结果包含行的内容的字符串但不包括任何行终止字符.若流的结尾已经到达，则为null

import java.io.*;

public class BufferedStreamDemo02 {
    public static void main(String[] args) throws IOException {
        /*
        //创建字符缓冲输出流
        BufferedWriter bw = new BufferedWriter(new FileWriter("19myCharStream\\bw.txt"));

        //写数据
        for (int i=0; i<10; i++){
            bw.write("hello" + i);
//            bw.write("\r\n");
            bw.newLine();
            bw.flush();
        }

        //释放资源
        bw.close();
         */

        //创建字符缓冲输入流
        BufferedReader br = new BufferedReader(new FileReader("19myCharStream\\bw.txt"));

        /*
        //第一次读取数据
        String line = br.readLine();
        System.out.println((line));

        //再读一行
        line = br.readLine();
        System.out.println((line));
        */

        String line;
        while ((line=br.readLine())!=null){
            System.out.println(line);
        }

        br.close();

    }
}
