package 为什么会出现字符流;
//需求，字节流读文本文件数据
//对于一个汉字存储：
//    GBK编码，占用2个字节
//    UTF-8编码，占用3个字节
import java.io.FileInputStream;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;

public class FileInputStreamDemo {
    public static void main(String[] args) throws UnsupportedEncodingException {
//        FileInputStream fis = new FileInputStream("19myCharStream\\a.txt");
//
//        int by;
//        while ((by = fis.read())!=-1){
//            System.out.println((char) by);
//        }
//
//        fis.close();

//        String s = "abc";
        String s = "中国";
//        byte[] bys = s.getBytes();
//        byte[] bys = s.getBytes("UTF-8");
        byte[] bys = s.getBytes("GBK");
        System.out.println(Arrays.toString(bys));
    }
}
