package 字符流中的编码解码问题;

import java.io.*;
//InputStreamReader:是从字节流到字符流的桥梁
//OutoutStreamWriter:是从字符流到字节流的桥梁

public class ConversionStreamDemo {
    public static void main(String[] args) throws IOException {
        OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream("19myCharStream\\osw.txt"),"UTF-8");
        osw.write("中国");
        osw.close();

        InputStreamReader isr = new InputStreamReader(new FileInputStream("19myCharStream\\osw.txt"),"GBK");
        //一次读取一个字符数据
        int ch;
        while ((ch=isr.read())!=-1){
            System.out.println((char) ch);
        }

        isr.close();
    }
}
