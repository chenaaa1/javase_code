package 递归求阶乘;

import java.io.File;

//通过递归遍历目录下的所有内容，并将文件的绝对路径输出
public class DiGuiDemo03 {
    public static void main(String[] args) {
        //根据给定的路径创建一个File对象
        File srcFile = new File("E:\\itcast");
        //调用方法
        getAllFilePath(srcFile);
    }

    //定义一个方法，用于获取给定目录下的所有内容，参数为第一步创建的File对象
    public static void getAllFilePath(File srcFile){
        //获取给定的File目录下所有的文件或者目录的File数组
        File[] fileArray = srcFile.listFiles();
        //遍历该File数组，得到每一个File对象
        if (fileArray != null){
            for (File file : fileArray){
                //判断该File对象是否是目录
                if (file.isDirectory()){
                    //是，递归调用
                    getAllFilePath(file);
                }else {
                    //不是，输出其绝对路径
                    System.out.println(file.getAbsolutePath());
                }
            }
        }
    }
}
