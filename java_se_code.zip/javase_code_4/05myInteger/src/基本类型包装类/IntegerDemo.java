package 基本类型包装类;

public class IntegerDemo {
    public static void main(String[] args) {
        //需求，我要判断一个数据是否在int范围内
        //public static final int MIN_VALUE
        //public static final int MAX_VALUE
        System.out.println(Integer.MIN_VALUE);
        System.out.println(Integer.MAX_VALUE);

    }
}
