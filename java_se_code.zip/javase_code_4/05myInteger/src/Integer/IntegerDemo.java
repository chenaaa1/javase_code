package Integer;
//静态方法获取对象：
//    public static Integer valueOf (int i):返回表示指定的int值的Integer实例
//    public static Integer valueOf (String s):返回一个保存指定值的Integer对象String

public class IntegerDemo {
    public static void main(String[] args) {
        Integer i1 = Integer.valueOf(100);
        System.out.println(i1);

//        Integer i2 = Integer.valueOf("abc");
        Integer i2 = Integer.valueOf("100");
        System.out.println(i2);
    }
}
