package com.itheima_01;

public class 创建工程过程 {
    public static void main(String[] args) {
        System.out.println("先创建空项目，注意不是java项目");
        System.out.println("添加模块,在src里添加软件包");
        System.out.println("src的软件包若取为com，则com下面的文件夹要取名com.itheima_01");
        System.out.println("这样会在com下创建itheima_01的文件");
        System.out.println("再在itheima_01中创建java类即可");
        System.out.println("新建模块则是打开'文件',再打开'项目结构'");
        System.out.println("调试过程中按f7即可进入下一步");
    }
}
